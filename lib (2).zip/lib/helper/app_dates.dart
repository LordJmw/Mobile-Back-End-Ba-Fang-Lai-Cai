class AppDates {
  static const int ANNIV_DAY = 24;
  static const int ANNIV_MONTH = 12;
}
