class base_url {
  static const String purchaseHistoryUrl =
      'http://10.0.2.2:3000/api/purchase-history';
}
