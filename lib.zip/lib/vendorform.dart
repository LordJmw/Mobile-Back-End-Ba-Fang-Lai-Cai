import 'package:flutter/material.dart';
import 'package:projek_uts_mbr/databases/vendorDatabase.dart';
import 'package:projek_uts_mbr/model/VendorModel.dart';

class VendorForm extends StatefulWidget {
  const VendorForm({super.key});

  @override
  State<VendorForm> createState() => _VendorFormState();
}

class _VendorFormState extends State<VendorForm> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _emailController = TextEditingController();
  final _teleponController = TextEditingController();

  String? _selectedCategory;
  List<String> categories = [];

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    final db = Vendordatabase();
    final cats = await db.getCategories();
    setState(() {
      categories = cats;
    });
  }

  void _saveVendor() async {
    if (_formKey.currentState!.validate() && _selectedCategory != null) {
      final penyediaBaru = Penyedia(
        nama: _namaController.text,
        deskripsi: "Deskripsi baru",
        rating: 0.0,
        harga: Harga(
          basic: TipePaket(harga: 100000, jasa: "Basic Service"),
          premium: TipePaket(harga: 200000, jasa: "Premium Service"),
          custom: TipePaket(harga: 300000, jasa: "Custom Service"),
        ),
        testimoni: [],
        email: _emailController.text,
        password: "password123",
        telepon: _teleponController.text,
        image: "https://via.placeholder.com/400x300",
      );

      final vendorModel = Vendormodel(
        kategori: _selectedCategory!,
        penyedia: [penyediaBaru],
      );

      final db = Vendordatabase();
      await db.insertVendor(vendorModel);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vendor berhasil ditambahkan!")),
      );

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Register Paket Anda")),
      body: Container(
        color: Colors.pink[50],
        child: Center(
          child: Card(
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            margin: const EdgeInsets.all(20),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Text(
                      "Form Vendor",
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.pink[300],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 25),

                    _buildField(Icons.person, "Nama Lengkap", _namaController),
                    const SizedBox(height: 15),

                    _buildField(
                      Icons.email,
                      "Email",
                      _emailController,
                      type: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 15),

                    _buildField(
                      Icons.phone,
                      "No HP",
                      _teleponController,
                      type: TextInputType.phone,
                    ),
                    const SizedBox(height: 15),

                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        labelText: "Kategori Vendor",
                        prefixIcon: Icon(
                          Icons.category,
                          color: Colors.pink[300],
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      value: _selectedCategory,
                      items: categories
                          .map(
                            (e) => DropdownMenuItem(value: e, child: Text(e)),
                          )
                          .toList(),
                      onChanged: (value) =>
                          setState(() => _selectedCategory = value),
                      validator: (value) =>
                          value == null ? "Pilih kategori" : null,
                    ),
                    const SizedBox(height: 30),

                    ElevatedButton.icon(
                      onPressed: _saveVendor,
                      icon: const Icon(Icons.save, color: Colors.white),
                      label: const Text(
                        "Simpan",
                        style: TextStyle(color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.pink[300],
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        elevation: 6,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField(
    IconData icon,
    String label,
    TextEditingController controller, {
    TextInputType type = TextInputType.text,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: type,
      maxLines: maxLines,
      validator: (value) => value == null || value.isEmpty
          ? "Field $label tidak boleh kosong"
          : null,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.pink[300]),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}
